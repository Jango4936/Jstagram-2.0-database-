
/**
 * Data Access Object (DAO) for managing user visibility settings in Jstagram 2.0.
 * Date Created: 2024-11-22
 * Purpose: Provides methods to interact with the `UserVisibility` table in the database.
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VisibilityDAO {

	/**
	 * Retrieves the visibility list for a specific user.
	 * 
	 * @param userID The ID of the user whose visibility list is to be retrieved.
	 * @return A list of Visibility objects representing the user's visibility list.
	 * @throws SQLException If a database error occurs.
	 */

	public static List<Visibility> getUserVisibilityList(int userID) throws SQLException {
		String sql = "SELECT * FROM UserVisibility WHERE userID = ? ORDER BY visibleUserID ASC";
		List<Visibility> visibilityList = new ArrayList<>();
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, userID); // current user

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Visibility visibility = new Visibility(rs.getInt("userID"), rs.getInt("visibleUserID"));
				visibilityList.add(visibility);
			}
		}
		return visibilityList;
	}

	/**
	 * Checks if a specific user is already in another user's visibility list.
	 * 
	 * @param userID        The ID of the user who owns the visibility list.
	 * @param visibleUserID The ID of the user to check in the visibility list.
	 * @return True if the user is in the visibility list, otherwise false.
	 * @throws SQLException If a database error occurs.
	 */

	public static boolean isUserInVisibilityList(int userID, int visibleUserID) throws SQLException {
		String sql = "SELECT 1 FROM UserVisibility WHERE userID = ? AND visibleUserID = ?";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, userID);
			pstmt.setInt(2, visibleUserID);
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		}
	}

	/**
	 * Adds a user to another user's visibility list.
	 * 
	 * @param currentUserID The ID of the user adding someone to their visibility
	 *                      list.
	 * @param userName      The username of the user to add.
	 * @throws SQLException If a database error occurs.
	 */

	public static void addUser(int currentUserID, String userName) throws SQLException {

		String sql = "INSERT INTO UserVisibility (userID, visibleUserID) VALUES (?, ?);";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, currentUserID);
			pstmt.setInt(2, UserDAO.getUserByUsername(userName).getUserID());
			pstmt.executeUpdate();

		}
	}

	/**
	 * Removes a user from another user's visibility list.
	 * 
	 * @param currentUserID The ID of the user removing someone from their
	 *                      visibility list.
	 * @param userName      The username of the user to remove.
	 * @throws SQLException If a database error occurs.
	 */

	public static void removeUser(int currentUserID, String userName) throws SQLException {

		String sql = "DELETE FROM UserVisibility WHERE userID = ? AND visibleUserID = ?;";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, currentUserID);
			pstmt.setInt(2, UserDAO.getUserByUsername(userName).getUserID());
			pstmt.executeUpdate();

		}
	}

	/**
	 * Deletes all visibility data associated with a specific user. Removes all
	 * entries where the user is either the owner or the visible user.
	 * 
	 * @param currentUser The user whose visibility data is to be deleted.
	 * @throws SQLException If a database error occurs.
	 */

	public static void deleteUserVisibilityList(User currentUser) throws SQLException {

		int currUserID = currentUser.getUserID();

		String sql = "DELETE FROM UserVisibility WHERE userID = ? OR visibleUserID = ?;";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, currUserID);
			pstmt.setInt(2, currUserID);
			pstmt.executeUpdate();

		}
	}

}
