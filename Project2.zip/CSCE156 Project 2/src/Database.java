
/**
 * Database connection utility for Jstagram 2.0.
 * Date Created: 2024-11-20
 * Purpose: Provides a reusable method to establish connections with the database. * 
 */

import java.sql.*;

public class Database {

	/**
	 * JDBC driver parameters
	 * 
	 * make sure use campus wifi, otherwise there will be significant delay when
	 * retrieving data
	 */
	public final static String hostname = "nuros.unl.edu";
	public final static String username = "zchua2"; // database username
	public final static String password = "shuFah5aingu"; // database password
	public final static String url = "jdbc:mysql://" + hostname + "/" + username;

	
	
	/**
	 * Establishes a connection to the database.
	 * 
	 * @return A Connection object representing the connection to the database.
	 * @throws SQLException If a database connection error occurs.
	 */

	public static Connection getConnection() throws SQLException {
		// Attempt to establish a connection to the database
		return DriverManager.getConnection(url, username, password);
	}
}




/*
 * For establishing connection locally (for performance)
 *  
 * JDBC driver parameters public final static String hostname = "localhost:3306";
 * public final static String username = "root";
 * database username public final static String password = "pass123";
 * database password public final static String url = "jdbc:mysql://" + hostname + "/" + "mydb";
 */