
/**
 * Provides methods for displaying various views in the Jstagram 2.0 application.
 * Date Created: 2024-11-20
 * Purpose: Handles the UI for menus, posts, and user interactions.
 */

import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Views {

	// ANSI escape codes for colored terminal output

	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_Green = "\u001B[32m";
	public static final String ANSI_Yellow = "\u001B[33m";
	public static final String ANSI_Blue = "\u001B[34m";
	public static final String ANSI_Purple = "\u001B[35m";
	public static final String ANSI_Cyan = "\u001B[36m";

	/**
	 * Displays the main menu of the application. Includes options for registering,
	 * logging in, or quitting.
	 * 
	 * @throws SQLException If a database error occurs while retrieving user
	 *                      statistics.
	 */

	public static void mainWindow() throws SQLException {
		System.out.println("fetching data from database...");
		int totalUser = UserDAO.getTotalUser();

		System.out.print(ANSI_Green);
		System.out.println(" =========================================");
		System.out.println("|         Welcome to Jstgram 2.0!         |");
		System.out.println("|                                         |");
		System.out.println("|               *************             |");
		System.out.println("|                     *                   |");
		System.out.println("|                     *                   |");
		System.out.println("|                     *                   |");
		System.out.println("|                     *                   |");
		System.out.println("|               *     *                   |");
		System.out.println("|               *******                   |");
		System.out.println("|                                         |");
		System.out.printf("| Current Number of User in Database : %-3d|\n", totalUser);
		System.out.println("|-----------------------------------------|");
		System.out.println("|   Register(R) or Login(L) or Quit(Q)    |");
		System.out.println(" =========================================");
		System.out.print(ANSI_RESET);
	}

	/**
	 * Displays the registration window for creating a new account.
	 */

	public static void accountRegistrationWindow() {
		System.out.print(ANSI_Yellow);
		System.out.println(" =========================================");
		System.out.println("|          Register New Account           |");
		System.out.println("|                                         |");
		System.out.println("|                                         |");
		System.out.println("|                                         |");
		System.out.println("|                                         |");
		System.out.println("|         * User Name   _______           |");
		System.out.println("|         * Password    _______           |");
		System.out.println("|                                         |");
		System.out.println("|                                         |");
		System.out.println(" =========================================");
		System.out.print(ANSI_RESET);
	}

	/**
	 * Displays the login window for existing users.
	 */

	public static void accountLoginWindow() {
		System.out.print(ANSI_Yellow);
		System.out.println(" =========================================");
		System.out.println("|           Login Your Account            |");
		System.out.println("|                                         |");
		System.out.println("|                                         |");
		System.out.println("|                                         |");
		System.out.println("|                                         |");
		System.out.println("|         * User Name   _______           |");
		System.out.println("|         * Password    _______           |");
		System.out.println("|                                         |");
		System.out.println("|                                         |");
		System.out.println(" =========================================");
		System.out.print(ANSI_RESET);
	}

	/**
	 * Displays the account management window. Includes options for posts,
	 * visibility settings, and account deletion.
	 * 
	 * @param currentUser The currently logged-in user.
	 */

	public static void accountWindow(User currentUser) {
		System.out.print(ANSI_Cyan);
		System.out.println(" =========================================");
		System.out.println("|             Account Window              |");
		System.out.println("|-----------------------------------------|");
		if (currentUser.getUserIsAdmin() == true) {
			System.out.print(ANSI_Cyan);
			System.out.print("|");
			System.out.print(ANSI_Green);
			System.out.print("         (A) Admin Menu                  ");
			System.out.print(ANSI_Cyan);
			System.out.print("|\n");
		}

		System.out.println("|         (P) Posts                       |");
		System.out.println("|         (V) Post Visibility             |");
		System.out.println("|         (-) Delete Current Account      |");
		System.out.println("|         (R) Return to Login Page        |");
		System.out.println("|         (Q) Quit                        |");
		System.out.println("|-----------------------------------------|");
		System.out.printf("|  Current User : %-10s              |\n", currentUser.getUserName());
		System.out.println(" =========================================");
		System.out.print(ANSI_RESET);
	}

	/**
	 * Displays the posts visible to the user. Allows interaction with posts, such
	 * as liking, sorting, or creating new posts.
	 * 
	 * @param currentUser The currently logged-in user.
	 * @param sortOrder   The sorting order for displaying posts.
	 * @throws SQLException If a database error occurs while retrieving posts.
	 */

	public static void postWindow(User currentUser, String sortOrder) throws SQLException {
		
		System.out.println("fetching post data from database...");
		
		List<Post> posts = PostDAO.getPostsVisibleToUser(currentUser.getUserID(), sortOrder);
		StringBuilder output = new StringBuilder();

		System.out.print(ANSI_Cyan);
		System.out.println(" =========================================");
		System.out.println("|           Post Visible to Me            |");
		System.out.println("|-----------------------------------------|");

		String liked;

		for (Post post : posts) {

			// Check if current post has liked by user
			if (post.getUserHasLiked() == true) {
				liked = " (Liked)";
			} else {
				liked = "";
			}

			// Wrap post content (make sure it doesnt exceed the border)
			List<String> wrappedContent = wrapText(post.getPostContent(), 37);
			for (String line : wrappedContent) {
				output.append("|").append(ANSI_Purple).append(String.format("  %-37s  ", line)).append(ANSI_Cyan)
						.append("|\n");
			}

			System.out.print(output);
			output.setLength(0);

			// get post author data and date created
			System.out.print("|");
			System.out.print(ANSI_Yellow);
			System.out.printf("  %37s  ", UserDAO.getUserByUserID(post.getUserID()).getUserName() + ", "
					+ post.getPostTime().format(DateTimeFormatter.ofPattern("h:mm:ssa, MMM dd, yyyy")));
			System.out.print(ANSI_Cyan);
			System.out.print("|\n");

			System.out.print("|");
			System.out.print(ANSI_Green);
			System.out.printf("  %37s  ",
					"PostID: " + post.getPostID() + ", " + post.getLikeCount() + " Likes" + liked);
			System.out.print(ANSI_Cyan);
			System.out.print("|\n");

			System.out.println("|-----------------------------------------|");
		}
		System.out.println("|         (+) Publish a new post          |");
		System.out.println("|         (L) Like a post                 |");
		System.out.println("|         (U) Unlike a post               |");
		System.out.println("|         (*) Sort post                   |");
		System.out.println("|         (R) Return                      |");
		System.out.println("|-----------------------------------------|");
		System.out.printf("|  Current User : %-10s              |\n", currentUser.getUserName());
		System.out.println(" =========================================");
		System.out.print(ANSI_RESET);

		posts.clear();
	}

	/**
	 * Displays options for sorting posts.
	 * 
	 * @param currentUser The currently logged-in user.
	 */

	public static void displayPostSortOption(User currentUser) {
		System.out.print(ANSI_Cyan);
		System.out.println(" =========================================");
		System.out.println("|   (+) Ascending Order of Time           |");
		System.out.println("|   (-) Descending Order of Time          |");
		System.out.println("|   (*) Ascending Order of Usernames      |");
		System.out.println("|   (=) Descending Order of Usernames     |");
		System.out.println("|   (^) Ascending Order of Likes          |");
		System.out.println("|   (~) Descending Order of Likes         |");
		System.out.printf("|-----------------------------------------|\n");
		System.out.printf("|  Current User : %-10s              |\n", currentUser.getUserName());
		System.out.println(" =========================================");
		System.out.print(ANSI_RESET);
	}

	/**
	 * Displays the visibility settings window. Lists the users currently visible to
	 * the logged-in user. Includes options to add or remove users from the
	 * visibility list.
	 * 
	 * @param currentUser The currently logged-in user.
	 * @throws SQLException If a database error occurs while retrieving visibility
	 *                      data.
	 */

	public static void visibilityWindow(User currentUser) throws SQLException {
		
		System.out.println("fetching visibility data from database...");
		
		List<Visibility> visibilityList = VisibilityDAO.getUserVisibilityList(currentUser.getUserID());

		System.out.print(ANSI_Cyan);
		System.out.println(" =========================================");
		System.out.println("|           My Visibility List            |");
		System.out.println("|-----------------------------------------|");
		System.out.println("|                                         |");

		for (Visibility visibility : visibilityList) {
			System.out.print(ANSI_Cyan);
			System.out.print("|");
			System.out.print(ANSI_Green);
			System.out.printf("  %-37s  ", UserDAO.getUserByUserID(visibility.getVisibleUserID()).getUserName());
			System.out.print(ANSI_Cyan);
			System.out.print("|\n");
		}

		System.out.println("|                                         |");
		System.out.println("|-----------------------------------------|");
		System.out.println("|         (+) Add a User                  |");
		System.out.println("|         (-) Remove a User               |");
		System.out.println("|         (R) Return                      |");
		System.out.println("|-----------------------------------------|");
		System.out.printf("|  Current User : %-10s              |\n", currentUser.getUserName());
		System.out.println(" =========================================");
		System.out.print(ANSI_RESET);
	}

	/**
	 * Displays the admin menu for users with admin privileges. Includes options for
	 * managing users and posts.
	 * 
	 * @param currentUser The currently logged-in admin user.
	 */

	public static void adminMenu(User currentUser) {

		System.out.print(ANSI_Cyan);
		System.out.println(" =========================================");
		System.out.println("|               Admin Menu                |");
		System.out.println("|-----------------------------------------|");
		System.out.println("|     (1) Specify New Admin User          |");
		System.out.println("|     (2) Create New User Account         |");
		System.out.println("|     (3) Delete Existing Account         |");
		System.out.println("|     (4) View All Posts                  |");
		System.out.println("|     (R) Return                          |");
		System.out.println("|-----------------------------------------|");
		System.out.printf("|  Current User : %-10s              |\n", currentUser.getUserName());
		System.out.println(" =========================================");
		System.out.print(ANSI_RESET);
	}

	/**
	 * Displays all posts in the system (admin access only). Allows interaction with
	 * posts, such as liking or sorting.
	 * 
	 * @param currentUser The currently logged-in admin user.
	 * @param sortOrder   The sorting order for displaying posts.
	 * @throws SQLException If a database error occurs while retrieving posts.
	 */

	public static void viewAllPost(User currentUser, String sortOrder) throws SQLException {
		
		System.out.println("fetching post data from database...");
		
		List<Post> posts = PostDAO.getAllPosts(currentUser.getUserID(), sortOrder);

		System.out.print(ANSI_Cyan);
		System.out.println(" =========================================");
		System.out.println("|               All Posts                 |");
		System.out.println("|-----------------------------------------|");

		String liked;

		for (Post post : posts) {

			StringBuilder output = new StringBuilder();

			if (post.getUserHasLiked() == true) {
				liked = " (Liked)";
			} else {
				liked = "";
			}

			// Wrap post content (make sure it doesnt exceed the border)
			List<String> wrappedContent = wrapText(post.getPostContent(), 37);
			for (String line : wrappedContent) {
				output.append("|").append(ANSI_Purple).append(String.format("  %-37s  ", line)).append(ANSI_Cyan)
						.append("|\n");
			}

			System.out.print(output);
			output.setLength(0);

			System.out.print("|");
			System.out.print(ANSI_Yellow);
			System.out.printf("  %37s  ", UserDAO.getUserByUserID(post.getUserID()).getUserName() + ", "
					+ post.getPostTime().format(DateTimeFormatter.ofPattern("h:mm:ssa, MMM dd, yyyy")));
			System.out.print(ANSI_Cyan);
			System.out.print("|\n");

			System.out.print("|");
			System.out.print(ANSI_Green);
			System.out.printf("  %37s  ",
					"PostID: " + post.getPostID() + ", " + post.getLikeCount() + " Likes" + liked);
			System.out.print(ANSI_Cyan);
			System.out.print("|\n");

			System.out.println("|-----------------------------------------|");
		}
		System.out.println("|         (+) Publish a new post          |");
		System.out.println("|         (L) Like a post                 |");
		System.out.println("|         (U) Unlike a post               |");
		System.out.println("|         (*) Sort post                   |");
		System.out.println("|         (R) Return                      |");
		System.out.println("|-----------------------------------------|");
		System.out.printf("|  Current User : %-10s              |\n", currentUser.getUserName());
		System.out.println(" =========================================");
		System.out.print(ANSI_RESET);

		posts.clear();
	}

	/**
	 * Wraps a block of text into lines of a specified maximum length.
	 * 
	 * @param text          The input text to wrap.
	 * @param maxLineLength The maximum number of characters per line.
	 * @return A list of strings, where each string represents a line of wrapped
	 *         text.
	 */

	public static List<String> wrapText(String text, int maxLineLength) {
		List<String> wrappedLines = new ArrayList<>();
		if (text == null || text.isEmpty()) {
			wrappedLines.add("");
			return wrappedLines;
		}

		String[] words = text.split("\\s+");
		StringBuilder currentLine = new StringBuilder();

		for (String word : words) {
			// Handle words longer than maxLineLength by splitting them
			while (word.length() > maxLineLength) {
				if (currentLine.length() > 0) {
					wrappedLines.add(currentLine.toString().trim());
					currentLine.setLength(0);
				}
				wrappedLines.add(word.substring(0, maxLineLength));
				word = word.substring(maxLineLength);
			}

			// If adding the word exceeds the line length, add the current line to
			// wrappedLines
			if (currentLine.length() + word.length() + 1 > maxLineLength) {
				wrappedLines.add(currentLine.toString().trim());
				currentLine.setLength(0);
			}

			// Add the word to the current line
			currentLine.append(word).append(" ");
		}

		// Add any remaining content
		if (currentLine.length() > 0) {
			wrappedLines.add(currentLine.toString().trim());
		}

		return wrappedLines;
	}

}
