/**
 * Represents the visibility relationship between users in Jstagram 2.0. 
 * Date Created: 2024-11-22 
 * Purpose: Manages the visibility data between a user and
 * the users they allow to see their posts.
 */

public class Visibility {
	private int userID;
	private int visibleUserID;

	/**
	 * Constructor for the Visibility class.
	 * 
	 * @param userID        The ID of the user who owns the visibility list.
	 * @param visibleUserID The ID of the user who is visible to the owner.
	 */

	public Visibility(int userID, int visibleUserID) {
		this.userID = userID;
		this.visibleUserID = visibleUserID;
	}

	/**
	 * Retrieves the user ID of the owner of the visibility list.
	 * 
	 * @return The user ID of the owner.
	 */

	public int getUserID() {
		return userID;
	}

	/**
	 * Retrieves the ID of the user who is visible to the owner.
	 * 
	 * @return The ID of the visible user.
	 */

	public int getVisibleUserID() {
		return visibleUserID;
	}

	/**
	 * Sets the user ID of the owner of the visibility list.
	 * 
	 * @param userID The user ID of the owner.
	 */

	public void setUserID(int userID) {
		this.userID = userID;
	}

	/**
	 * Sets the ID of the user who is visible to the owner.
	 * 
	 * @param visibleUserID The ID of the visible user.
	 */

	public void setVisibleUserID(int visibleUserID) {
		this.visibleUserID = visibleUserID;
	}

	/**
	 * Provides a string representation of the Visibility object. Includes the owner
	 * user ID and the visible user ID.
	 * 
	 * @return A string representation of the visibility relationship.
	 */

	@Override
	public String toString() {
		return "Visibility(" + "userID=" + userID + ", visibleUserID=" + visibleUserID + ')';
	}
}
