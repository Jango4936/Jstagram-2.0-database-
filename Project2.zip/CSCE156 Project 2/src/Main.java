
/**
 * Main class for Jstagram 2.0
 * Handles user interaction, login, registration, and post viewing.
 * 
 * Author: Chua Zhen Keat
 * Date: 2024-11-20
 */

import java.sql.SQLException;
import java.util.*;

public class Main {
	private static Scanner scanner = new Scanner(System.in);
	private static String input = "";
	private static boolean isRunning = true;
	private static String sortOrder = "postTime ASC";
	public static User currentUser;
	protected static boolean isAccesThroughAdminMenu = false;

	/**
	 * Main entry point of the application.
	 * 
	 * @param args Command-line arguments.
	 * @throws SQLException If a database error occurs.
	 */

	public static void main(String[] args) throws SQLException {

		while (isRunning == true) {
			Views.mainWindow(); // call mainmenu page

			while (true) {

				do {
					System.out.print("Choose: ");
					input = scanner.nextLine();

					if (!input.isEmpty() && input.length() == 1) {
						break;
					} else if (input.isBlank()) {
						System.out.println("Invalid input, please don't leave it blank");
					} else if (input.length() > 1) {
						System.out.println("Invalid input, please enter only 1 character!!");
					}

				} while (input.isBlank() || input.length() > 1); // loop and make sure user input is valid

				char option = input.charAt(0); // option variable store user's current choice

				switch (Character.toLowerCase(option)) {
				case 'r':
					register(); // if user choose r, call register method
					break;
				case 'l':
					login(); // if user choose l, call login method
					break;
				case 'q':
					isRunning = false; // if user choose q, terminated the program
					break;
				default:
					System.out.println("Invalid input. Please enter 'r', 'l', or 'q'");
					// if user input incorrect character
				}
				if (isRunning == false) {
					break; // terminated the program and end the while loop
				}
			}

		}
		System.out.println("Program terminated");

	}

	/**
	 * Handles user login functionality. Validates user credentials and navigates to
	 * the account window if successful.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void login() throws SQLException {
		sortOrder = "postTime ASC"; // default sort order every time login
		Views.accountLoginWindow(); // call login page

		// ask user to enter their details
		System.out.print("Enter UserName: ");
		String userName = scanner.nextLine();
		System.out.print("Enter password: ");
		String password = scanner.nextLine();

		System.out.println("Validating...pleasewait...");

		if (UserDAO.loginCheck(userName, password) == true) {
			System.out.println(
					"\nAccount login successfully!! Welcome " + userName + "!!" + " Press any key to continue...");
			// welcome message
			scanner.nextLine();
			System.out.println("Retriving data from current user...please wait...");
			currentUser = UserDAO.getUserByUsername(userName);

			viewAccountWindow();

		} else {
			System.out.println("Invalid username or password. Please try again!! Press any key to continue...");
			scanner.nextLine(); // pause gap :)
			Views.mainWindow(); // go back to mainmenu page
		}

	}

	/**
	 * Handles user registration functionality. Validates inputs and registers a new
	 * user if the username is available.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void register() throws SQLException {

		Views.accountRegistrationWindow();

		// ask user to enter their details
		System.out.print("Enter UserName: ");
		String userName = scanner.nextLine();
		System.out.print("Enter password: ");
		String password = scanner.nextLine();

		System.out.println("Processing...pleasewait...");

		// if current username is not blank and does not exist in database, proceed to
		// register
		if (userName.equals("")) {
			System.out.println("Username is invalid. Press any key to continue...");
			scanner.nextLine(); // pause gap :)

		} else if (!UserDAO.userCheck(userName)) {

			UserDAO.registerUser(userName, password);
			System.out.println("Account created sucessfully");
			Views.mainWindow();

		} else {
			System.out.println("Current username is taken. Please try again!! Press any key to continue...");
			scanner.nextLine(); // pause gap :)
			Views.mainWindow(); // go back to mainmenu page
		}

	}

	/**
	 * Navigates to the account window after successful login. Handles user options
	 * like viewing posts, managing visibility, or logging out.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void viewAccountWindow() throws SQLException {
		Views.accountWindow(currentUser);
		while (true) {
			do {
				System.out.print("Choose: ");
				input = scanner.nextLine();
				if (!input.isEmpty() && input.length() == 1) {
					break;
				} else if (input.isBlank()) {
					System.out.println("Invalid input, please don't leave it blank");
				} else if (input.length() > 1) {
					System.out.println("Invalid input, please enter only 1 character!!");
				}

			} while (input.isBlank() || input.length() > 1); // loop and make sure user input is valid

			char option = input.charAt(0);

			switch (Character.toLowerCase(option)) {
			case 'a':
				if (currentUser.getUserIsAdmin() == true) {
					adminMenu();
				} else {
					System.out.println("Invalid input. Please enter a valid option");
				}

				break;
			case 'p': // if user choose p, call viewPosts method
				viewPosts();
				break;
			case 'v': // if user choose v, call viewPostsVisibility method
				viewPostsVisibility();
				break;
			case '-': // if user choose -, call deleteCurrentAccount method
				deleteCurrentAccount();
				break;
			case 'r': // if user choose r, logout
				System.out.println("Logging out...");
				currentUser = null;
				Views.mainWindow();
				break;
			case 'q': // if user choose q, quit everything
				isRunning = false; // terminate the program
				break;
			default:
				System.out.println("Invalid input. Please enter a valid option");
			}
			if (isRunning == false || currentUser == null) {
				break; // if user choose to terminate the program or logout, break the loop
			}
		}

	}

	/**
	 * Deletes the current user account after confirmation. Removes all related data
	 * such as posts and visibility settings.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void deleteCurrentAccount() throws SQLException {

		System.out.println("Are you sure you want to delete your account? (y/n)");

		boolean status = true;
		while (status == true) {
			do {
				System.out.print("Choose: ");
				input = scanner.nextLine();
				if (!input.isEmpty() && input.length() == 1) {
					break;
				} else if (input.isBlank()) {
					System.out.println("Invalid input, please don't leave it blank");
				} else if (input.length() > 1) {
					System.out.println("Invalid input, please enter only 1 character!!");
				}

			} while (input.isBlank() || input.length() > 1); // loop and make sure user input is valid

			char option = input.charAt(0);

			switch (Character.toLowerCase(option)) {
			case 'y': // user choose yes, delete all the data
				VisibilityDAO.deleteUserVisibilityList(currentUser);
				PostDAO.deletePost(currentUser);
				UserDAO.deleteUser(currentUser);
				Views.mainWindow();
				currentUser = null;
				status = false;
				break;
			case 'n': // user choose no, go back
				Views.accountWindow(currentUser);
				status = false;
				break;
			default:
				System.out.println("Invalid input. Please enter a valid option");
			}
			if (currentUser == null) {
				break; // if user choose to delete the account, break the loop
			}
		}

	}

	/**
	 * Displays posts visible to the current user. Allows users to interact with
	 * posts, including publishing, liking, and sorting.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void viewPosts() throws SQLException {
		Views.postWindow(currentUser, sortOrder);

		boolean status = true;

		while (status == true) {

			do {
				// this inner loop is to make sure user dont leave the input blank or type more
				// than 1 char
				System.out.print("Choose: ");
				input = scanner.nextLine();

				if (!input.isEmpty() && input.length() == 1) {
					break;
				} else if (input.isBlank()) {
					System.out.println("Invalid input, please don't leave it blank");
				} else if (input.length() > 1) {
					System.out.println("Invalid input, please enter only 1 character!!");
				}

			} while (input.isBlank() || input.length() > 1); // loop and make sure user input is valid

			char option = input.charAt(0);
			switch (Character.toLowerCase(option)) {
			case '+': // publish new post
				publishNewPost();
				Views.postWindow(currentUser, sortOrder);
				break;
			case 'l': // like a post
				likePost();
				Views.postWindow(currentUser, sortOrder);
				break;
			case 'u': // unlike a post
				unlikePost();
				Views.postWindow(currentUser, sortOrder);
				break;
			case '*': // sort post
				sortPostMenu();
				if (isAccesThroughAdminMenu == true) {
					Views.viewAllPost(currentUser, sortOrder);
				} else {
					Views.postWindow(currentUser, sortOrder);
				}
				break;
			case 'r':
				// user change his mind? return to Account Window
				Views.accountWindow(currentUser);
				status = false; // for breaking the while loop
				break;
			default:
				System.out.println("Invalid input. Please enter a valid options!!");
			}
			if (status == false) {
				break; // break the loop
			}
		}

	}

	/**
	 * Allows the user to publish a new post. Prompts the user for content and
	 * updates the database.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void publishNewPost() throws SQLException {
		System.out.print("Enter your text: ");
		input = scanner.nextLine();
		PostDAO.publishNewPost(currentUser.getUserID(), input);

	}

	/**
	 * Allows the user to like a post. Validates post visibility and checks if the
	 * post has already been liked.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void likePost() throws SQLException {
		System.out.print("Enter the Post ID you want to like: ");
		input = scanner.nextLine();
		int postID;
		try {
			postID = Integer.parseInt(input);
		} catch (NumberFormatException e) {
			System.out.println("Invalid Post ID. Please enter a valid number. Press any key to continue...");
			scanner.nextLine();
			return;
		}

		// Check if the post is visible to the current user and not access by admin menu
		if (!PostDAO.isPostVisibleToUser(postID, currentUser.getUserID()) && isAccesThroughAdminMenu == false) {
			System.out.println("Invalid Post ID. Please enter a valid number. Press any key to continue...");
			scanner.nextLine();
			return;
		}

		// Check if user has already liked the post
		if (PostDAO.hasUserLikedPost(currentUser.getUserID(), postID)) {
			System.out.println("You have already liked this post. Press any key to continue...");
			scanner.nextLine();
			return;
		}

		// Like the post
		PostDAO.likePost(currentUser.getUserID(), postID);
		System.out.println("You have liked the post. Press any key to continue...");
		scanner.nextLine();
	}

	/**
	 * Allows the user to unlike a post. Validates post visibility and checks if the
	 * post has already been liked.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void unlikePost() throws SQLException {
		System.out.print("Enter the Post ID you want to unlike: ");
		input = scanner.nextLine();
		int postID;
		try {
			postID = Integer.parseInt(input);
		} catch (NumberFormatException e) {
			System.out.println("Invalid Post ID. Please enter a valid number. Press any key to continue...");
			scanner.nextLine(); // pause gap :)
			return;
		}

		// Check if the post is visible to the current user and not access by admin menu
		if (!PostDAO.isPostVisibleToUser(postID, currentUser.getUserID()) && isAccesThroughAdminMenu == false) {
			System.out.println("Invalid Post ID. Please enter a valid number. Press any key to continue...");
			scanner.nextLine(); // pause gap :)
			return;
		}

		// Check if user has liked the post
		if (!PostDAO.hasUserLikedPost(currentUser.getUserID(), postID)) {
			System.out.println("You have not liked this post yet. Press any key to continue...");
			scanner.nextLine(); // pause gap :)
			return;
		}

		// Unlike the post
		PostDAO.unlikePost(currentUser.getUserID(), postID);
		System.out.println("You have unliked the post. Press any key to continue...");
		scanner.nextLine(); // pause gap :)
	}

	/**
	 * Displays the sorting options for posts. Updates the sorting order based on
	 * user input.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void sortPostMenu() throws SQLException {
		Views.displayPostSortOption(currentUser);

		boolean status = true;

		while (status == true) {

			do {
				// this inner loop is to make sure user dont leave the input blank or type more
				// than 1 char
				System.out.print("Choose: ");
				input = scanner.nextLine();

				if (!input.isEmpty() && input.length() == 1) {
					break;
				} else if (input.isBlank()) {
					System.out.println("Invalid input, please don't leave it blank");
				} else if (input.length() > 1) {
					System.out.println("Invalid input, please enter only 1 character!!");
				}

			} while (input.isBlank() || input.length() > 1); // loop and make sure user input is valid

			char option = input.charAt(0);
			switch (Character.toLowerCase(option)) {
			case '+': // sort post in time ascending
				sortOrder = "postTime ASC";
				status = false;
				break;
			case '-': // sort post in time descending
				sortOrder = "postTime DESC";
				status = false;
				break;
			case '*': // sort post in username alphabet ascending
				sortOrder = "userName ASC";
				status = false;
				break;
			case '=': // sort post in username alphabet descending
				sortOrder = "userName DESC";
				status = false;
				break;
			case '^': // sort post in like count ascending
				sortOrder = "(SELECT COUNT(*)FROM PostLikes WHERE PostLikes.postID = Posts.postID) ASC;";
				status = false;
				break;
			case '~': // sort post in like count descending
				sortOrder = "(SELECT COUNT(*)FROM PostLikes WHERE PostLikes.postID = Posts.postID) DESC;";
				status = false;
				break;

			default:
				System.out.println("Invalid input. Please enter a valid options!!");
			}
			if (status == false) {
				break; // break the loop
			}
		}

	}

	/**
	 * Manages the visibility list for the current user. Allows adding or removing
	 * users from the visibility list.
	 * 
	 * @throws SQLException If a database error occurs.
	 */
	private static void viewPostsVisibility() throws SQLException {
		Views.visibilityWindow(currentUser);

		boolean status = true;

		while (status == true) {

			do {
				// this inner loop is to make sure user dont leave the input blank or type more
				// than 1 char
				System.out.print("Choose: ");
				input = scanner.nextLine();

				if (!input.isEmpty() && input.length() == 1) {
					break;
				} else if (input.isBlank()) {
					System.out.println("Invalid input, please don't leave it blank");
				} else if (input.length() > 1) {
					System.out.println("Invalid input, please enter only 1 character!!");
				}

			} while (input.isBlank() || input.length() > 1); // loop and make sure user input is valid

			char option = input.charAt(0);
			switch (Character.toLowerCase(option)) {
			case '+': // user choose add a user to visibility list option
				addUserToVisibilityList();
				Views.visibilityWindow(currentUser);

				break;
			case '-': // user choose remove a user to visibility list option
				removeUserFromVisibilityList();
				Views.visibilityWindow(currentUser);

				break;
			case 'r':
				// user change his mind? return to account window
				Views.accountWindow(currentUser);
				status = false; // for breaking the while loop
				break;
			default:
				System.out.println("Invalid input. Please enter a valid options!!");
			}
			if (status == false) {
				break; // break the loop
			}
		}

	}

	/**
	 * Adds a user to the current user's visibility list. Validates the input and
	 * updates the database.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void addUserToVisibilityList() throws SQLException {
		System.out.print("Enter a username: ");
		input = scanner.nextLine();

		// if user enter his own name
		if (input.toLowerCase().equals(currentUser.getUserName().toLowerCase())) {
			System.out.println("You cant add yourself!! Press any key to continue...");
			scanner.nextLine(); // pause gap :)

		} // if entered user exist in database and is not in current user visibility list
		else if (UserDAO.userCheck(input) == true && !VisibilityDAO.isUserInVisibilityList(currentUser.getUserID(),
				UserDAO.getUserByUsername(input).getUserID())) {

			System.out.println("Updating data...please wait...");
			VisibilityDAO.addUser(currentUser.getUserID(), input);

		} else {
			System.out.println("Invalid username Please try again!! Press any key to continue...");
			scanner.nextLine(); // pause gap :)
		}

	}

	/**
	 * Removes a user from the current user's visibility list. Validates the input
	 * and updates the database.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void removeUserFromVisibilityList() throws SQLException {
		System.out.print("Enter a username: ");
		input = scanner.nextLine();

		// if user enter his own name
		if (input.toLowerCase().equals(currentUser.getUserName().toLowerCase())) {
			System.out.println("You cant remove yourself!! Press any key to continue...");
			scanner.nextLine(); // pause gap :)

		} // if entered user exist in database
		else if (UserDAO.userCheck(input) == true) {

			System.out.println("Updating data...please wait...");
			VisibilityDAO.removeUser(currentUser.getUserID(), input);

		} else {
			System.out.println("Invalid username Please try again!! Press any key to continue...");
			scanner.nextLine(); // pause gap :)
		}

	}

	/**
	 * Displays the admin menu for users with admin privileges. Provides options for
	 * user management and viewing posts.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void adminMenu() throws SQLException {
		Views.adminMenu(currentUser);

		isAccesThroughAdminMenu = true;

		boolean status = true;

		while (status == true) {

			do {
				// this inner loop is to make sure user don't leave the input blank or type more
				// than 1 char
				System.out.print("Choose: ");
				input = scanner.nextLine();

				if (!input.isEmpty() && input.length() == 1) {
					break;
				} else if (input.isBlank()) {
					System.out.println("Invalid input, please don't leave it blank");
				} else if (input.length() > 1) {
					System.out.println("Invalid input, please enter only 1 character!!");
				}

			} while (input.isBlank() || input.length() > 1); // loop and make sure user input is valid

			char option = input.charAt(0);
			switch (Character.toLowerCase(option)) {
			case '1':	// specify a new admin user from existing username
				specifyNewAdminUser();
				Views.adminMenu(currentUser);
				break;
			case '2':	// create a New User Account
				createNewUserAccount();
				Views.adminMenu(currentUser);
				break;
			case '3':	//	delete existing account from existing username
				deleteExistingAccount();
				Views.adminMenu(currentUser);
				break;
			case '4':	// view all Posts in database
				viewAllPosts();
				Views.adminMenu(currentUser);
				break;
			case 'r':	// admin change his mind? return to normal account window
				Views.accountWindow(currentUser);
				status = false; // for breaking the while loop
				break;
			default:
				System.out.println("Invalid input. Please enter a valid options!!");
			}
			if (status == false) {
				break; // break the loop
			}
		}

		isAccesThroughAdminMenu = false;

	}

	/**
	 * Promotes a specified user to admin status. Validates the input and updates
	 * the database.
	 */

	public static void specifyNewAdminUser() {

		System.out.print("Enter the username to promote to admin: ");
		String userName = scanner.nextLine();

		System.out.println("Processing...pleasewait...");

		try {
			if (userName.toLowerCase().equals(currentUser.getUserName().toLowerCase())) {
				System.out.println("You can't enter yourself");
				scanner.nextLine(); // pause gap :)

			} else if (UserDAO.userCheck(userName) == true) {
				User user = UserDAO.getUserByUsername(userName);
				user.setUserIsAdmin(true);
				UserDAO.updateUser(user);
				System.out.println("User " + userName + " is now an admin. Press any key to continue...");
				scanner.nextLine(); // pause gap :)
			} else {
				System.out.print("User not found. Press any key to continue...");
				scanner.nextLine(); // pause gap :)
			}
		} catch (SQLException e) {
			System.out.println("Error promoting user to admin.");
			e.printStackTrace();
		}
	}

	/**
	 * Creates a new user account through the admin menu. Uses a try-catch block for
	 * error handling.
	 */

	public static void createNewUserAccount() {
		System.out.print("Enter new username: ");
		String userName = scanner.nextLine();
		System.out.print("Enter password: ");
		String password = scanner.nextLine();
		try {
			
			// if entered username is blank
			if (userName.equals("")) {
				System.out.println("Username is invalid. Press any key to continue...");
				scanner.nextLine(); // pause gap :)

			} // check if current username is taken
			else if (!UserDAO.userCheck(userName)) {
				UserDAO.registerUser(userName, password);
				System.out.println("Account created sucessfully. Press any key to continue...");
				scanner.nextLine(); // pause gap :)

			} else {
				System.out.println("Username already exists. Press any key to continue...");
				scanner.nextLine(); // pause gap :)

			}
		} catch (SQLException e) {
			System.out.println("Error creating user account.");
			e.printStackTrace();
		}
	}

	/**
	 * Deletes an existing user account through the admin menu. Uses a try-catch
	 * block for error handling.
	 */

	private static void deleteExistingAccount() {
		System.out.print("Enter a username to delete: ");
		input = scanner.nextLine();

		try {
			// if admin enter his own name
			if (input.toLowerCase().equals(currentUser.getUserName().toLowerCase())) {
				System.out.println("You cant delete yourself here!! Press any key to continue...");
				scanner.nextLine(); // pause gap :)

			} // check if current username exist in database
			else if (UserDAO.userCheck(input) == true) {

				User user = UserDAO.getUserByUsername(input);

				// Delete user data in order
				VisibilityDAO.deleteUserVisibilityList(user);
				PostDAO.deletePost(user);
				UserDAO.deleteUser(user);
				System.out.println("User " + user.getUserName() + " deleted successfully.");
			} else {
				System.out.println("Invalid username Please try again!! Press any key to continue...");
				scanner.nextLine(); // pause gap :)
			}
		} catch (SQLException e) {
			System.out.println("Error deleting user.");
			e.printStackTrace();
		}
	}

	/**
	 * Views all posts in the system (admin access only). Allows admins to interact
	 * with posts.
	 * 
	 * @throws SQLException If a database error occurs.
	 */

	private static void viewAllPosts() throws SQLException {
		Views.viewAllPost(currentUser, sortOrder);

		boolean status = true;

		while (status == true) {

			do {
				// this inner loop is to make sure user dont leave the input blank or type more
				// than 1 char
				System.out.print("Choose: ");
				input = scanner.nextLine();

				if (!input.isEmpty() && input.length() == 1) {
					break;
				} else if (input.isBlank()) {
					System.out.println("Invalid input, please don't leave it blank");
				} else if (input.length() > 1) {
					System.out.println("Invalid input, please enter only 1 character!!");
				}

			} while (input.isBlank() || input.length() > 1); // loop and make sure user input is valid

			char option = input.charAt(0);
			switch (Character.toLowerCase(option)) {
			case '+':	// publish a new post
				publishNewPost();
				Views.viewAllPost(currentUser, sortOrder);
				break;
			case 'l':	// like a post, ignored visibility
				likePost();
				Views.viewAllPost(currentUser, sortOrder);
				break;
			case 'u':	// unlike a post, ignored visibility
				unlikePost();
				Views.viewAllPost(currentUser, sortOrder);
				break;
			case '*':	// sort post
				sortPostMenu();
				Views.viewAllPost(currentUser, sortOrder);
				break;
			case 'r':
				// admin change his mind? go back
				status = false; // for breaking the while loop

				break;
			default:
				System.out.println("Invalid input. Please enter a valid options!!");
			}
			if (status == false) {
				break; // break the loop
			}
		}

	}
}
