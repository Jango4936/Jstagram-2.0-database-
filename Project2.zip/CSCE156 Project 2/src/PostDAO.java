
/**
 * Data Access Object (DAO) for managing posts in Jstagram 2.0.
 * Date Created: 2024-11-21
 * Purpose: Provides methods to interact with the `Posts` table in the database.
 */

import java.sql.*;
import java.util.*;
import java.time.LocalDateTime;

public class PostDAO {

	/**
	 * Retrieves all posts from the database.
	 * 
	 * @param currentUserID The ID of the currently logged-in user.
	 * @param sortOrder     The sorting order for the posts.
	 * @return A list of all posts.
	 * @throws SQLException If a database error occurs.
	 */

	public static List<Post> getAllPosts(int currentUserID, String sortOrder) throws SQLException {
		String sql;

		if (sortOrder == "userName ASC" || sortOrder == "userName DESC") {
			sql = "SELECT * FROM Posts JOIN User ON Posts.userID = User.userID";
		} else {
			sql = "SELECT * FROM Posts";
		}

		sql += " ORDER BY " + sortOrder; // this query is handled internally, so no need to worry about sql injection

		List<Post> posts = new ArrayList<>();
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Post post = new Post(rs.getInt("postID"), rs.getInt("userID"), rs.getString("postContent"),
						rs.getTimestamp("postTime").toLocalDateTime());

				post.setLikeCount(getLikeCount(post.getPostID()));
				post.setUserHasLiked(hasUserLikedPost(currentUserID, post.getPostID()));

				posts.add(post);
			}
		}
		return posts;
	}

	/**
	 * Retrieves posts visible to a specific user.
	 * 
	 * @param currentUserID The ID of the user requesting the posts.
	 * @param sortOrder     The sorting order for the posts.
	 * @return A list of visible posts.
	 * @throws SQLException If a database error occurs.
	 */

	public static List<Post> getPostsVisibleToUser(int currentUserID, String sortOrder) throws SQLException {
		String sql;

		if (sortOrder == "userName ASC" || sortOrder == "userName DESC") {
			sql = "SELECT Posts.* FROM Posts JOIN User ON Posts.userID = User.userID WHERE Posts.userID = ? OR Posts.userID IN (SELECT userID FROM UserVisibility WHERE visibleUserID = ?)";
		} else {
			sql = "SELECT * FROM Posts WHERE userID = ? OR userID IN (SELECT userID FROM UserVisibility WHERE visibleUserID = ?)";
		}

		sql += " ORDER BY " + sortOrder; // this query is handled internally, so no need to worry about sql injection

		List<Post> posts = new ArrayList<>();
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, currentUserID);
			pstmt.setInt(2, currentUserID);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Post post = new Post(rs.getInt("postID"), rs.getInt("userID"), rs.getString("postContent"),
						rs.getTimestamp("postTime").toLocalDateTime());

				post.setLikeCount(getLikeCount(post.getPostID()));
				post.setUserHasLiked(hasUserLikedPost(currentUserID, post.getPostID()));

				posts.add(post);
			}
		}
		return posts;
	}

	/**
	 * Publishes a new post in the database.
	 * 
	 * @param currentUserID The ID of the user creating the post.
	 * @param postContent   The content of the new post.
	 * @throws SQLException If a database error occurs.
	 */

	public static void publishNewPost(int currentUserID, String postContent) throws SQLException {
		String sql = "insert into Posts(userID,postContent,postTime) values (?,?,?)";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, currentUserID);
			pstmt.setString(2, postContent);
			pstmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
			pstmt.executeUpdate();

		}
	}

	/**
	 * Deletes all posts created by a specific user. Removes associated likes before
	 * deleting the posts.
	 * 
	 * @param user The user whose posts are to be deleted.
	 * @throws SQLException If a database error occurs.
	 */

	public static void deletePost(User user) throws SQLException {

		// delete data in postLike table
		String sql = "DELETE FROM PostLikes WHERE userID = ? OR postID IN (SELECT postID FROM Posts WHERE userID = ?);";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, user.getUserID());
			pstmt.setInt(2, user.getUserID());
			pstmt.executeUpdate();

		}

		// delete data in Posts table
		sql = " DELETE FROM Posts WHERE userID = ?;";

		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, user.getUserID());
			pstmt.executeUpdate();

		}
	}

	/**
	 * Likes a specific post on behalf of a user.
	 * 
	 * @param userID The ID of the user liking the post.
	 * @param postID The ID of the post being liked.
	 * @throws SQLException If a database error occurs.
	 */

	public static void likePost(int userID, int postID) throws SQLException {
		String sql = "INSERT INTO PostLikes (postID, userID) VALUES (?, ?)";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, postID);
			pstmt.setInt(2, userID);
			pstmt.executeUpdate();
		}
	}

	/**
	 * Removes a like from a specific post on behalf of a user.
	 * 
	 * @param userID The ID of the user unliking the post.
	 * @param postID The ID of the post being unliked.
	 * @throws SQLException If a database error occurs.
	 */

	public static void unlikePost(int userID, int postID) throws SQLException {
		String sql = "DELETE FROM PostLikes WHERE postID = ? AND userID = ?";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, postID);
			pstmt.setInt(2, userID);
			pstmt.executeUpdate();
		}
	}

	/**
	 * Retrieves the number of likes for a specific post.
	 * 
	 * @param postID The ID of the post.
	 * @return The like count for the post.
	 * @throws SQLException If a database error occurs.
	 */

	public static int getLikeCount(int postID) throws SQLException {
		String sql = "SELECT COUNT(*) AS likeCount FROM PostLikes WHERE postID = ?";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, postID);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt("likeCount");
			} else {
				return 0;
			}
		}
	}

	/**
	 * Checks if a user has liked a specific post.
	 * 
	 * @param userID The ID of the user.
	 * @param postID The ID of the post.
	 * @return True if the user has liked the post, otherwise false.
	 * @throws SQLException If a database error occurs.
	 */

	public static boolean hasUserLikedPost(int userID, int postID) throws SQLException {
		String sql = "SELECT 1 FROM PostLikes WHERE postID = ? AND userID = ?";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, postID);
			pstmt.setInt(2, userID);
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		}
	}

	/**
	 * Checks if a specific post is visible to a user.
	 * 
	 * @param postID The ID of the post.
	 * @param userID The ID of the user.
	 * @return True if the post is visible to the user, otherwise false.
	 * @throws SQLException If a database error occurs.
	 */

	public static boolean isPostVisibleToUser(int postID, int userID) throws SQLException {
		String sql = "SELECT 1 FROM Posts WHERE postID = ? AND (Posts.userID = ? OR EXISTS (SELECT 1 FROM UserVisibility WHERE UserVisibility.userID = Posts.userID AND UserVisibility.visibleUserID = ?))";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, postID);
			pstmt.setInt(2, userID);
			pstmt.setInt(3, userID);
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		}
	}

}
