/**
 * Represents a user in the Jstagram 2.0 application.
 * Date Created: 2024-11-20
 * Purpose: Manages user-related data, including user credentials and
 * privileges.
 */

public class User {
	private int userID;
	private String userName;
	private String userPassword;
	private boolean isAdmin;

	/**
	 * Constructor for the User class.
	 * 
	 * @param userID       Unique identifier for the user.
	 * @param userName     The username of the user.
	 * @param userPassword The password of the user.
	 * @param isAdmin      Indicates whether the user has admin privileges.
	 */

	User(int userID, String userName, String userPassword, boolean isAdmin) {
		this.userID = userID;
		this.userName = userName;
		this.userPassword = userPassword;
		this.isAdmin = isAdmin;
	}

	/**
	 * Retrieves the user ID.
	 * 
	 * @return The unique identifier for the user.
	 */

	public int getUserID() {
		return userID;
	}

	/**
	 * Retrieves the username.
	 * 
	 * @return The username of the user.
	 */

	public String getUserName() {
		return userName;
	}

	/**
	 * Retrieves the user's password.
	 * 
	 * @return The password of the user.
	 */

	public String getUserPassword() {
		return userPassword;
	}

	/**
	 * Checks if the user has admin privileges.
	 * 
	 * @return True if the user is an admin, otherwise false.
	 */

	public boolean getUserIsAdmin() {
		return isAdmin;
	}

	/**
	 * Sets the user ID.
	 * 
	 * @param userID The unique identifier for the user.
	 */

	public void setUserID(int userID) {
		this.userID = userID;
	}

	/**
	 * Sets the username.
	 * 
	 * @param userName The username of the user.
	 */

	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Sets the user's password.
	 * 
	 * @param userPassword The password of the user.
	 */

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	/**
	 * Sets the admin status for the user.
	 * 
	 * @param isAdmin True if the user should have admin privileges, otherwise
	 *                false.
	 */

	public void setUserIsAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	/**
	 * Provides a string representation of the User object. Includes the user ID,
	 * username, password, and admin status.
	 * 
	 * @return A string representation of the user.
	 */

	@Override
	public String toString() {
		return "User(" + userID + ", " + userName + ", " + userPassword + ", " + isAdmin + ")";
	}

}
