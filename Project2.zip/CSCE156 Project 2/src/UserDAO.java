
/**
 * Data Access Object (DAO) for managing user-related operations in Jstagram 2.0.
 * Date Created: 2024-11-20
 * Purpose: Provides methods to interact with the `User` table in the database.
 */

import java.sql.*;

public class UserDAO {

	/**
	 * Updates a user's information in the database.
	 * 
	 * @param user The User object containing updated information.
	 * @throws SQLException If a database error occurs.
	 */

	public static void updateUser(User user) throws SQLException {
		String sql = "UPDATE User SET userName = ?, userPassword = ?, isAdmin = ? WHERE userID = ?";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getUserPassword());
			pstmt.setBoolean(3, user.getUserIsAdmin());
			pstmt.setInt(4, user.getUserID());
			pstmt.executeUpdate();
		}
	}

	/**
	 * Retrieves the total number of users in the database.
	 * 
	 * @return The total user count.
	 * @throws SQLException If a database error occurs.
	 */

	public static int getTotalUser() throws SQLException {
		String query = "SELECT COUNT(*) FROM User";
		try (Connection conn = Database.getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(query)) {

			if (rs.next()) {
				int count = rs.getInt(1);
				conn.close();
				return count;
			} else {
				conn.close();
				return 0;
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Checks if a username exists in the database.
	 * 
	 * @param username The username to check.
	 * @return True if the username exists, otherwise false.
	 * @throws SQLException If a database error occurs.
	 */

	public static boolean userCheck(String username) throws SQLException {
		String query = "SELECT * FROM User WHERE userName = ?";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		}
	}

	/**
	 * Validates user login credentials.
	 * 
	 * @param username The username entered by the user.
	 * @param password The password entered by the user.
	 * @return True if the credentials are valid, otherwise false.
	 * @throws SQLException If a database error occurs.
	 */

	public static boolean loginCheck(String username, String password) throws SQLException {
		String query = "SELECT * FROM User WHERE userName = ? and userPassword = ?";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		}

	}

	/**
	 * Registers a new user in the database.
	 * 
	 * @param userName The username of the new user.
	 * @param password The password of the new user.
	 * @throws SQLException If a database error occurs.
	 */

	public static void registerUser(String userName, String password) throws SQLException {

		String sql = "INSERT INTO User (userName, userPassword) VALUES (?, ?);";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setString(1, userName);
			pstmt.setString(2, password);
			pstmt.executeUpdate();

		}
	}

	/**
	 * Deletes a user and their data from the database.
	 * 
	 * @param currentUser The User object representing the user to delete.
	 * @throws SQLException If a database error occurs.
	 */

	public static void deleteUser(User currentUser) throws SQLException {

		String sql = "DELETE FROM User WHERE userID = ?;";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, currentUser.getUserID());
			pstmt.executeUpdate();

		}
	}

	/**
	 * Retrieves a user from the database by their user ID.
	 * 
	 * @param userID The ID of the user to retrieve.
	 * @return A User object representing the retrieved user, or null if not found.
	 * @throws SQLException If a database error occurs.
	 */

	public static User getUserByUserID(int userID) throws SQLException {
		String sql = "SELECT * FROM User WHERE userID = ?";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, userID);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return new User(rs.getInt("userID"), rs.getString("userName"), rs.getString("userPassword"),
						rs.getBoolean("isAdmin"));
			}
		}
		return null;
	}

	/**
	 * Retrieves a user from the database by their username.
	 * 
	 * @param username The username of the user to retrieve.
	 * @return A User object representing the retrieved user, or null if not found.
	 * @throws SQLException If a database error occurs.
	 */

	public static User getUserByUsername(String username) throws SQLException {
		String sql = "SELECT * FROM User WHERE userName = ?";
		try (Connection conn = Database.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return new User(rs.getInt("userID"), rs.getString("userName"), rs.getString("userPassword"),
						rs.getBoolean("isAdmin"));
			}
		}
		return null;
	}

}
