
/**
 * Represents a social media post in Jstagram 2.0.
 * Date Created: 2024-11-20
 * Purpose: Manages post-related data, including content, author, and metadata.
 */

import java.time.LocalDateTime;

public class Post {
	private int postID;
	private int userID;
	private String postContent;
	private LocalDateTime postTime;

	private int likeCount;
	private boolean userHasLiked;

	/**
	 * Constructor for the Post class.
	 * 
	 * @param postID      Unique identifier for the post.
	 * @param userID      ID of the user who created the post.
	 * @param postContent Content of the post.
	 * @param postTime    Timestamp of when the post was created.
	 */

	Post(int postID, int userID, String postContent, LocalDateTime postTime) {
		this.postID = postID;
		this.userID = userID;
		this.postContent = postContent;
		this.postTime = postTime;

		this.likeCount = 0;
		this.userHasLiked = false;
	}

	/**
	 * Retrieves the post ID.
	 * 
	 * @return The unique identifier for the post.
	 */

	public int getPostID() {
		return postID;
	}

	/**
	 * Retrieves the user ID of the post's creator.
	 * 
	 * @return The user ID.
	 */

	public int getUserID() {
		return userID;
	}

	/**
	 * Retrieves the content of the post.
	 * 
	 * @return The post content.
	 */

	public String getPostContent() {
		return postContent;
	}

	/**
	 * Retrieves the timestamp of when the post was created.
	 * 
	 * @return The creation time of the post.
	 */

	public LocalDateTime getPostTime() {
		return postTime;
	}

	/**
	 * Retrieves the number of likes for the post.
	 * 
	 * @return The like count.
	 */

	public int getLikeCount() {
		return likeCount;
	}

	/**
	 * Sets the number of likes for the post.
	 * 
	 * @param likeCount The like count.
	 */

	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

	/**
	 * Sets the post ID.
	 * 
	 * @param postID The unique identifier for the post.
	 */

	public void setPostID(int postID) {
		this.postID = postID;
	}

	/**
	 * Sets the user ID of the post's creator.
	 * 
	 * @param userID The user ID.
	 */

	public void setUserID(int userID) {
		this.userID = userID;
	}

	/**
	 * Sets the content of the post.
	 * 
	 * @param postContent The post content.
	 */

	public void setPostContent(String postContent) {
		this.postContent = postContent;
	}

	/**
	 * Sets the timestamp of when the post was created.
	 * 
	 * @param postTime The creation time of the post.
	 */

	public void setpostTime(LocalDateTime postTime) {
		this.postTime = postTime;
	}

	/**
	 * Checks if the current user has liked the post.
	 * 
	 * @return True if the user has liked the post, otherwise false.
	 */

	public boolean getUserHasLiked() {
		return userHasLiked;
	}

	/**
	 * Sets whether the current user has liked the post.
	 * 
	 * @param userHasLiked True if the user has liked the post, otherwise false.
	 */

	public void setUserHasLiked(boolean userHasLiked) {
		this.userHasLiked = userHasLiked;
	}

	/**
	 * Provides a string representation of the post object. Includes post ID, user
	 * ID, content, and creation time.
	 * 
	 * @return A string representation of the post.
	 */

	@Override
	public String toString() {
		return "User(" + postID + ", " + userID + ", " + postContent + ", " + postTime + ")";
	}

}
